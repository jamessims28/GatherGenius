import { NextResponse } from "next/server";
import { getSupabaseAdmin } from "@/lib/supabaseAdmin";

export async function POST(req) {
  const body = await req.json();
  const supabase = getSupabaseAdmin();

  if (!supabase) {
    return NextResponse.json({
      ok: false,
      mode: "placeholder",
      message: "Add Supabase keys to persist booking status.",
      update: body
    });
  }

  const { error } = await supabase
    .from("vendor_bookings")
    .update({ status: body.status })
    .eq("booking_code", body.bookingId);

  if (error) return NextResponse.json({ ok: false, message: error.message }, { status: 500 });

  return NextResponse.json({ ok: true, message: "Booking status updated." });
}
