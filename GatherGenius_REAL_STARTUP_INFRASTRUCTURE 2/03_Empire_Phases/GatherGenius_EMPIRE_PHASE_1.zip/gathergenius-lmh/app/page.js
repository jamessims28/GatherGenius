"use client";

import React, { useMemo, useState } from "react";
import {
  Store, Crown, BarChart3, Wallet, Users, Search, Star, MapPin,
  Building2, UserPlus, CheckCircle2, CreditCard, Upload, LayoutDashboard,
  Sparkles, ShieldCheck, TrendingUp, Megaphone, ClipboardList
} from "lucide-react";

const businessName = process.env.NEXT_PUBLIC_BUSINESS_NAME || "LMH Enterprise LLC";

const vendorPlans = [
  { key: "free", name: "Starter Listing", price: 0, monthly: "$0/mo", features: ["Basic vendor card", "Marketplace visibility", "Booking request form"], rank: 1 },
  { key: "featured", name: "Featured Vendor", price: 49, monthly: "$49/mo", features: ["Featured placement", "Higher search ranking", "Verified-style badge", "Booking lead priority"], rank: 2 },
  { key: "elite", name: "Elite Partner", price: 149, monthly: "$149/mo", features: ["Top placement", "Homepage spotlight", "Category sponsorship", "Priority onboarding"], rank: 3 }
];

const seedVendors = [
  { id: 1, name: "Elite Sound DJs", category: "DJ / Music", city: "Stafford, VA", plan: "featured", rating: 4.9, revenue: 1450, bookings: 6, leads: 24, verified: true },
  { id: 2, name: "Fresh Flame Catering", category: "Catering", city: "Fredericksburg, VA", plan: "elite", rating: 4.8, revenue: 3820, bookings: 9, leads: 36, verified: true },
  { id: 3, name: "GlowPro Lighting", category: "Lighting / AV", city: "Washington, DC", plan: "free", rating: 4.7, revenue: 680, bookings: 3, leads: 12, verified: false },
  { id: 4, name: "Venue Luxe Hall", category: "Venue", city: "Stafford, VA", plan: "featured", rating: 4.9, revenue: 5200, bookings: 4, leads: 18, verified: true },
  { id: 5, name: "CivicStage Productions", category: "Political / Civic", city: "Northern VA", plan: "elite", rating: 4.6, revenue: 7600, bookings: 5, leads: 29, verified: false }
];

const seedBookings = [
  { id: "BK-1001", customer: "James Sims", vendor: "Elite Sound DJs", event: "Family BBQ", amount: 850, commission: 85, status: "Requested" },
  { id: "BK-1002", customer: "Nicole", vendor: "Fresh Flame Catering", event: "Wedding", amount: 4200, commission: 420, status: "Confirmed" },
  { id: "BK-1003", customer: "Tanya", vendor: "Venue Luxe Hall", event: "Corporate Mixer", amount: 2500, commission: 250, status: "Pending Deposit" },
  { id: "BK-1004", customer: "Joshua", vendor: "CivicStage Productions", event: "Town Hall", amount: 6800, commission: 680, status: "Confirmed" }
];

function money(v) {
  return new Intl.NumberFormat("en-US", { style: "currency", currency: "USD" }).format(Number(v || 0));
}

async function postJson(path, body) {
  const response = await fetch(path, {
    method: "POST",
    headers: {"Content-Type":"application/json"},
    body: JSON.stringify(body)
  });
  return response.json();
}

export default function Page() {
  const [tab, setTab] = useState("empire");
  const [vendors, setVendors] = useState(seedVendors);
  const [bookings, setBookings] = useState(seedBookings);
  const [query, setQuery] = useState("");
  const [status, setStatus] = useState("Empire Phase 1 ready: vendor monetization, bookings, and revenue tracking.");
  const [newVendor, setNewVendor] = useState({ name: "", category: "DJ / Music", city: "", plan: "free" });

  const filteredVendors = vendors
    .filter(v => `${v.name} ${v.category} ${v.city}`.toLowerCase().includes(query.toLowerCase()))
    .sort((a, b) => {
      const ap = vendorPlans.find(p => p.key === a.plan)?.rank || 0;
      const bp = vendorPlans.find(p => p.key === b.plan)?.rank || 0;
      return bp - ap || b.rating - a.rating;
    });

  const monthlyVendorRevenue = useMemo(() => vendors.reduce((sum, vendor) => {
    const plan = vendorPlans.find(p => p.key === vendor.plan);
    return sum + Number(plan?.price || 0);
  }, 0), [vendors]);

  const bookingRevenue = useMemo(() => bookings.reduce((sum, booking) => sum + Number(booking.commission || 0), 0), [bookings]);
  const grossBookingVolume = useMemo(() => bookings.reduce((sum, booking) => sum + Number(booking.amount || 0), 0), [bookings]);
  const totalPlatformRevenue = monthlyVendorRevenue + bookingRevenue;
  const totalLeads = vendors.reduce((sum, vendor) => sum + Number(vendor.leads || 0), 0);

  const tabs = [
    ["empire", LayoutDashboard, "Empire HQ"],
    ["vendors", Store, "Vendor Admin"],
    ["plans", Crown, "Paid Listings"],
    ["bookings", ClipboardList, "Bookings"],
    ["revenue", BarChart3, "Revenue"],
    ["marketplace", Search, "Marketplace"],
    ["deploy", Upload, "Deploy"]
  ];

  async function createVendorSubscription(planKey, vendorName) {
    const data = await postJson("/api/vendor-subscriptions/create", { plan: planKey, vendorName, businessName });
    setStatus(data.message || "Vendor subscription route called.");
    if (data.url) window.location.href = data.url;
  }

  async function featureVendor(id) {
    setVendors(prev => prev.map(v => v.id === id ? { ...v, plan: "featured" } : v));
    await postJson("/api/vendors/feature", { vendorId: id, plan: "featured" });
    setStatus("Vendor upgraded to Featured placement.");
  }

  async function addVendor() {
    if (!newVendor.name.trim()) {
      setStatus("Add a vendor business name first.");
      return;
    }
    const vendor = {
      id: Date.now(),
      ...newVendor,
      rating: "New",
      revenue: 0,
      bookings: 0,
      leads: 0,
      verified: false
    };
    setVendors(prev => [vendor, ...prev]);
    const data = await postJson("/api/vendors/join", { vendor, businessName });
    setStatus(data.message || "Vendor added to admin pipeline.");
    setNewVendor({ name: "", category: "DJ / Music", city: "", plan: "free" });
  }

  async function updateBookingStatus(id, nextStatus) {
    setBookings(prev => prev.map(b => b.id === id ? { ...b, status: nextStatus } : b));
    await postJson("/api/bookings/update", { bookingId: id, status: nextStatus });
    setStatus(`Booking ${id} updated to ${nextStatus}.`);
  }

  return (
    <main className="min-h-screen px-5 py-7">
      <div className="mx-auto max-w-7xl">
        <header className="panel rounded-[2rem] p-5 md:p-6 mb-7 flex flex-wrap justify-between gap-5 items-center">
          <div className="flex items-center gap-4">
            <div className="orb-sm"></div>
            <div>
              <h1 className="text-3xl md:text-4xl font-light tracking-[.08em] uppercase">GatherGenius Empire</h1>
              <p className="text-sm text-stone-500">Vendor monetization system for {businessName}</p>
            </div>
          </div>
          <div className="rounded-full bg-white/70 border border-stone-200 px-5 py-3 text-sm">
            Empire Phase 1
          </div>
        </header>

        <nav className="panel rounded-[2rem] p-2 flex flex-wrap gap-2 mb-8">
          {tabs.map(([key, Icon, label]) => (
            <button key={key} onClick={() => setTab(key)} className={`rounded-[1.35rem] px-4 py-2 text-sm flex items-center gap-2 ${tab === key ? "primary" : "btn"}`}>
              <Icon className="h-4 w-4" />{label}
            </button>
          ))}
        </nav>

        {tab === "empire" && (
          <Section icon={Sparkles} title="Empire HQ" text="Your command center for vendor revenue, booking commissions, featured placements, and marketplace growth.">
            <div className="grid md:grid-cols-5 gap-4 mb-6">
              <Metric icon={Wallet} label="Platform Revenue" value={money(totalPlatformRevenue)} />
              <Metric icon={Crown} label="Vendor MRR" value={money(monthlyVendorRevenue)} />
              <Metric icon={CreditCard} label="Booking Fees" value={money(bookingRevenue)} />
              <Metric icon={Store} label="Vendors" value={vendors.length} />
              <Metric icon={TrendingUp} label="Leads" value={totalLeads} />
            </div>
            <div className="grid lg:grid-cols-3 gap-6">
              <Card className="lg:col-span-2">
                <h3 className="text-2xl font-light mb-4">Empire Growth Engine</h3>
                <div className="grid md:grid-cols-2 gap-4">
                  {[
                    ["Vendor subscriptions", "Charge vendors for listing tiers and featured placement."],
                    ["Booking commissions", "Take a platform fee from confirmed bookings."],
                    ["Marketplace search", "Rank paid vendors higher in category and city search."],
                    ["LMH revenue tracking", "Track MRR, booking fees, gross volume, and leads."]
                  ].map(([title, text]) => (
                    <div key={title} className="rounded-2xl bg-white/65 border border-stone-200 p-4">
                      <h4 className="font-medium">{title}</h4>
                      <p className="text-sm text-stone-500 mt-2">{text}</p>
                    </div>
                  ))}
                </div>
              </Card>
              <Card>
                <h3 className="text-2xl font-light mb-4">Next Money Move</h3>
                <p className="text-stone-500 mb-5">Start by converting real vendors into Featured and Elite paid listings.</p>
                <button onClick={() => setTab("plans")} className="primary rounded-2xl px-5 py-3 w-full">Open Paid Listings</button>
              </Card>
            </div>
          </Section>
        )}

        {tab === "vendors" && (
          <Section icon={Store} title="Vendor Admin Dashboard" text="Approve vendors, upgrade listings, verify providers, and control marketplace placement.">
            <Card>
              <h3 className="text-xl font-light mb-4">Add Vendor to Pipeline</h3>
              <div className="grid md:grid-cols-5 gap-3">
                <Field label="Business Name" value={newVendor.name} set={v => setNewVendor({...newVendor, name: v})} />
                <Field label="Category" value={newVendor.category} set={v => setNewVendor({...newVendor, category: v})} />
                <Field label="City" value={newVendor.city} set={v => setNewVendor({...newVendor, city: v})} />
                <label>
                  <span className="text-xs text-stone-500">Plan</span>
                  <select value={newVendor.plan} onChange={e => setNewVendor({...newVendor, plan: e.target.value})} className="mt-1 w-full rounded-2xl border border-stone-200 bg-white/70 px-4 py-3 outline-none">
                    {vendorPlans.map(p => <option key={p.key} value={p.key}>{p.name}</option>)}
                  </select>
                </label>
                <button onClick={addVendor} className="primary rounded-2xl px-4 py-3 self-end">Add Vendor</button>
              </div>
            </Card>

            <div className="grid md:grid-cols-2 xl:grid-cols-3 gap-4 mt-6">
              {vendors.map(vendor => {
                const plan = vendorPlans.find(p => p.key === vendor.plan);
                return (
                  <Card key={vendor.id}>
                    <div className="flex justify-between gap-3">
                      <div>
                        <h3 className="text-xl font-light">{vendor.name}</h3>
                        <p className="text-stone-500">{vendor.category}</p>
                      </div>
                      <span className="text-xs rounded-full bg-white/75 border border-stone-200 px-3 py-1 h-fit">{plan?.name}</span>
                    </div>
                    <p className="text-sm text-stone-500 mt-3"><MapPin className="inline h-4 w-4 mr-1" />{vendor.city}</p>
                    <div className="grid grid-cols-3 gap-3 my-5 text-center">
                      <Mini label="Leads" value={vendor.leads} />
                      <Mini label="Bookings" value={vendor.bookings} />
                      <Mini label="Revenue" value={money(vendor.revenue)} />
                    </div>
                    <div className="grid grid-cols-2 gap-2">
                      <button onClick={() => featureVendor(vendor.id)} className="btn rounded-2xl px-4 py-3">Feature</button>
                      <button onClick={() => setVendors(prev => prev.map(v => v.id === vendor.id ? {...v, verified: !v.verified} : v))} className="primary rounded-2xl px-4 py-3">
                        {vendor.verified ? "Verified" : "Verify"}
                      </button>
                    </div>
                  </Card>
                );
              })}
            </div>
          </Section>
        )}

        {tab === "plans" && (
          <Section icon={Crown} title="Paid Vendor Listings" text="Turn vendors into monthly recurring revenue with listing tiers.">
            <div className="grid md:grid-cols-3 gap-4">
              {vendorPlans.map(plan => (
                <Card key={plan.key}>
                  <h3 className="text-2xl font-light">{plan.name}</h3>
                  <p className="text-4xl font-light my-4">{plan.monthly}</p>
                  <div className="space-y-3 min-h-36">
                    {plan.features.map(feature => (
                      <p key={feature} className="text-stone-600"><CheckCircle2 className="inline h-4 w-4 mr-2 text-emerald-700" />{feature}</p>
                    ))}
                  </div>
                  <button onClick={() => createVendorSubscription(plan.key, "Vendor")} className="primary rounded-2xl px-5 py-3 mt-5 w-full">
                    Activate {plan.name}
                  </button>
                </Card>
              ))}
            </div>
          </Section>
        )}

        {tab === "bookings" && (
          <Section icon={ClipboardList} title="Booking Request Pipeline" text="Track vendor booking requests, deposits, confirmations, and LMH platform commissions.">
            <div className="grid gap-3">
              {bookings.map(booking => (
                <div key={booking.id} className="panel rounded-[1.75rem] p-4 grid lg:grid-cols-7 gap-3 items-center">
                  <div>
                    <p className="font-medium">{booking.id}</p>
                    <p className="text-xs text-stone-500">{booking.event}</p>
                  </div>
                  <p>{booking.customer}</p>
                  <p>{booking.vendor}</p>
                  <p>{money(booking.amount)}</p>
                  <p className="text-emerald-700">{money(booking.commission)}</p>
                  <p>{booking.status}</p>
                  <select value={booking.status} onChange={e => updateBookingStatus(booking.id, e.target.value)} className="rounded-2xl border border-stone-200 bg-white/70 px-4 py-3 outline-none">
                    <option>Requested</option>
                    <option>Pending Deposit</option>
                    <option>Confirmed</option>
                    <option>Completed</option>
                    <option>Cancelled</option>
                  </select>
                </div>
              ))}
            </div>
          </Section>
        )}

        {tab === "revenue" && (
          <Section icon={BarChart3} title="LMH Enterprise LLC Revenue Tracker" text="Owner-level revenue view for subscriptions, booking commissions, and marketplace movement.">
            <div className="grid md:grid-cols-4 gap-4 mb-6">
              <Metric icon={Wallet} label="Total Platform Revenue" value={money(totalPlatformRevenue)} />
              <Metric icon={Building2} label="Gross Booking Volume" value={money(grossBookingVolume)} />
              <Metric icon={Crown} label="Vendor MRR" value={money(monthlyVendorRevenue)} />
              <Metric icon={CreditCard} label="Booking Commission" value={money(bookingRevenue)} />
            </div>
            <Card>
              <h3 className="text-xl font-light mb-4">Revenue Breakdown</h3>
              <div className="space-y-3">
                <Progress label="Vendor MRR" value={monthlyVendorRevenue} total={totalPlatformRevenue || 1} />
                <Progress label="Booking Fees" value={bookingRevenue} total={totalPlatformRevenue || 1} />
                <Progress label="Featured/Elite Vendors" value={vendors.filter(v => v.plan !== "free").length} total={vendors.length || 1} suffix=" vendors" />
              </div>
            </Card>
          </Section>
        )}

        {tab === "marketplace" && (
          <Section icon={Search} title="Marketplace Ranking Preview" text="Paid vendors rise higher in public search results and city/category pages.">
            <Card>
              <div className="flex gap-3">
                <div className="flex-1 rounded-full bg-white/75 border border-stone-200 px-5 py-4 flex items-center gap-3">
                  <Search className="h-5 w-5 text-stone-400" />
                  <input value={query} onChange={e => setQuery(e.target.value)} placeholder="Search vendor, city, category..." className="w-full bg-transparent outline-none" />
                </div>
                <button className="primary rounded-full px-7 py-4">Search</button>
              </div>
            </Card>
            <div className="grid md:grid-cols-2 xl:grid-cols-3 gap-4 mt-6">
              {filteredVendors.map(vendor => {
                const plan = vendorPlans.find(p => p.key === vendor.plan);
                return (
                  <Card key={vendor.id}>
                    <div className="flex justify-between gap-3">
                      <div>
                        <h3 className="text-xl font-light">{vendor.name}</h3>
                        <p className="text-stone-500">{vendor.category}</p>
                      </div>
                      <span className="flex items-center gap-1 text-sm"><Star className="h-4 w-4" />{vendor.rating}</span>
                    </div>
                    <p className="text-sm text-stone-500 mt-3"><MapPin className="inline h-4 w-4 mr-1" />{vendor.city}</p>
                    <div className="mt-4 flex gap-2 flex-wrap">
                      <span className="rounded-full bg-white/75 border border-stone-200 px-3 py-1 text-xs">{plan?.name}</span>
                      {vendor.verified && <span className="rounded-full bg-emerald-50 text-emerald-700 border border-emerald-100 px-3 py-1 text-xs">Verified</span>}
                    </div>
                    <button className="primary rounded-2xl px-4 py-3 mt-5 w-full">Request Booking</button>
                  </Card>
                );
              })}
            </div>
          </Section>
        )}

        {tab === "deploy" && (
          <Section icon={Upload} title="Deploy Empire Phase 1" text="Deploy this monetization layer on Vercel.">
            <Card>
              <ol className="list-decimal ml-5 space-y-3 text-stone-600">
                <li>Use project name: <code>gathergenius-lmh</code></li>
                <li>Upload to GitHub or import ZIP contents.</li>
                <li>Add Stripe keys and vendor price IDs.</li>
                <li>Run <code>docs/EMPIRE_SCHEMA.sql</code> in Supabase.</li>
                <li>Redeploy.</li>
              </ol>
            </Card>
          </Section>
        )}

        <footer className="mt-10 text-sm text-stone-500 flex justify-between gap-3 flex-wrap">
          <p>© 2026 GatherGenius. Empire revenue directed to {businessName}.</p>
          <p>{status}</p>
        </footer>
      </div>
    </main>
  );
}

function Section({ icon: Icon, title, text, children }) {
  return (
    <section>
      <div className="mb-6">
        <div className="flex gap-3 items-center">
          <Icon className="text-stone-500" />
          <h2 className="text-4xl font-light">{title}</h2>
        </div>
        <p className="text-stone-500">{text}</p>
      </div>
      {children}
    </section>
  );
}

function Card({ children, className = "" }) {
  return <div className={`panel rounded-[1.75rem] p-5 ${className}`}>{children}</div>;
}

function Field({ label, value, set }) {
  return (
    <label>
      <span className="text-xs text-stone-500">{label}</span>
      <input value={value} onChange={e => set(e.target.value)} className="mt-1 w-full rounded-2xl border border-stone-200 bg-white/70 px-4 py-3 outline-none" />
    </label>
  );
}

function Metric({ icon: Icon, label, value }) {
  return (
    <Card>
      <div className="flex gap-3 items-center">
        <div className="orb-sm scale-75"></div>
        <div>
          <p className="text-sm text-stone-500">{label}</p>
          <p className="text-xl font-light">{value}</p>
        </div>
      </div>
    </Card>
  );
}

function Mini({ label, value }) {
  return (
    <div className="rounded-2xl bg-white/65 border border-stone-200 p-3">
      <p className="text-xs text-stone-500">{label}</p>
      <p className="font-medium">{value}</p>
    </div>
  );
}

function Progress({ label, value, total, suffix = "" }) {
  const pct = Math.min(100, Math.round((Number(value) / Number(total || 1)) * 100));
  return (
    <div>
      <div className="flex justify-between text-sm mb-2">
        <span>{label}</span>
        <span>{typeof value === "number" && suffix === "" ? money(value) : `${value}${suffix}`}</span>
      </div>
      <div className="h-3 rounded-full bg-white/70 border border-stone-200 overflow-hidden">
        <div className="h-full bg-stone-800" style={{ width: `${pct}%` }}></div>
      </div>
    </div>
  );
}
