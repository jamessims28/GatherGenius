# GatherGenius Empire Phase 1

## Added

- Vendor admin dashboard
- Paid listing tiers
- Featured placement system
- Booking request pipeline
- LMH Enterprise LLC revenue tracker
- Vendor MRR tracking
- Booking commission tracking
- Marketplace ranking preview
- Stripe vendor subscription checkout scaffold

## Vendor listing prices

Create Stripe monthly prices:

```env
STRIPE_VENDOR_PRICE_FEATURED=
STRIPE_VENDOR_PRICE_ELITE=
```

Suggested prices:

- Featured Vendor: $49/month
- Elite Partner: $149/month

## Supabase

Run:

```text
docs/EMPIRE_SCHEMA.sql
```

## Vercel

Project name:

```text
gathergenius-lmh
```
