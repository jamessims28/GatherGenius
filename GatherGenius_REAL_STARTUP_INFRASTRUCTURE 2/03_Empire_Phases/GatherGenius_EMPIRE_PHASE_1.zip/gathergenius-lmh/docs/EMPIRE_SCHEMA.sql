alter table vendors add column if not exists plan text default 'free';
alter table vendors add column if not exists featured boolean default false;
alter table vendors add column if not exists leads integer default 0;
alter table vendors add column if not exists booking_count integer default 0;
alter table vendors add column if not exists platform_revenue numeric default 0;

create table if not exists vendor_listing_subscriptions (
  id uuid primary key default gen_random_uuid(),
  vendor_id uuid,
  vendor_name text,
  plan text,
  stripe_subscription_id text unique,
  status text default 'active',
  amount numeric,
  business_name text default 'LMH Enterprise LLC',
  created_at timestamptz default now()
);

create table if not exists vendor_bookings (
  id uuid primary key default gen_random_uuid(),
  booking_code text unique,
  customer_name text,
  customer_email text,
  vendor_name text,
  event_name text,
  amount numeric,
  commission numeric,
  status text default 'Requested',
  metadata jsonb,
  created_at timestamptz default now()
);

create table if not exists marketplace_revenue_events (
  id uuid primary key default gen_random_uuid(),
  revenue_type text,
  source_name text,
  amount numeric,
  business_name text default 'LMH Enterprise LLC',
  metadata jsonb,
  created_at timestamptz default now()
);
