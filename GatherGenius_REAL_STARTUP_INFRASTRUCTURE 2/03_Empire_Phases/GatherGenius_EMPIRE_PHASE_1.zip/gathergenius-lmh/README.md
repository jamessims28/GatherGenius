# GatherGenius Empire Phase 1

Use Vercel project name:

```text
gathergenius-lmh
```

Empire Phase 1 includes:
- Vendor admin dashboard
- Paid listing tiers
- Featured placement system
- Booking request pipeline
- LMH Enterprise LLC revenue tracker
- Stripe vendor subscription route
- Supabase Empire schema

Read:
- `docs/EMPIRE_PHASE_1.md`
- `docs/EMPIRE_SCHEMA.sql`
