 "use client";
import React,{useState} from "react";
import {Smartphone,Brain,BarChart3,Globe} from "lucide-react";

export default function Page(){
 const [tab,setTab]=useState("phase3");

 return (
  <main className="p-6">
   <h1 className="text-3xl mb-4">Empire Phase 3</h1>

   <div className="flex gap-3 mb-6">
    <button onClick={()=>setTab("mobile")}>Mobile</button>
    <button onClick={()=>setTab("ai")}>AI Autopilot</button>
    <button onClick={()=>setTab("investor")}>Investor</button>
    <button onClick={()=>setTab("global")}>Global</button>
   </div>

   {tab==="mobile" && (
    <div>
     <h2 className="text-xl flex gap-2"><Smartphone/> Mobile App Ready</h2>
     <p>iOS + Android expansion enabled.</p>
    </div>
   )}

   {tab==="ai" && (
    <div>
     <h2 className="text-xl flex gap-2"><Brain/> AI Autopilot</h2>
     <p>Automatically plan entire events.</p>
    </div>
   )}

   {tab==="investor" && (
    <div>
     <h2 className="text-xl flex gap-2"><BarChart3/> Investor Dashboard</h2>
     <p>View revenue, growth, and expansion metrics.</p>
    </div>
   )}

   {tab==="global" && (
    <div>
     <h2 className="text-xl flex gap-2"><Globe/> Global Expansion</h2>
     <p>Scale platform nationwide and worldwide.</p>
    </div>
   )}
  </main>
 )
}
