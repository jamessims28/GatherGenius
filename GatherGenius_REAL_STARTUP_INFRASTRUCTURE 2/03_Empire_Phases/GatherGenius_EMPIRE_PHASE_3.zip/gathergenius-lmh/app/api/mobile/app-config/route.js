import { NextResponse } from "next/server";
export async function GET(){
 return NextResponse.json({ok:true,platform:"mobile-ready",features:["vendors","map","booking","ai"]});
}
