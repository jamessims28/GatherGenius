import { NextResponse } from "next/server";
export async function POST(req){
  const body = await req.json();
  return NextResponse.json({
    ok:true,
    message:"AI vendor matching ready.",
    matches:[
      {vendor:"Elite Sound DJs", score:0.95},
      {vendor:"Fresh Flame Catering", score:0.91}
    ]
  });
}
