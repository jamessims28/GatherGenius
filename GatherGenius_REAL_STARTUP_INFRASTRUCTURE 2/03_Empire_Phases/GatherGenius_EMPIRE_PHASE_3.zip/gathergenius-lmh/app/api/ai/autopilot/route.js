import { NextResponse } from "next/server";
export async function POST(req){
 const body=await req.json();
 return NextResponse.json({
  ok:true,
  message:"AI autopilot event created",
  plan:{
   vendors:["DJ","Catering","Venue"],
   timeline:["Setup","Event","Cleanup"]
  }
 });
}
