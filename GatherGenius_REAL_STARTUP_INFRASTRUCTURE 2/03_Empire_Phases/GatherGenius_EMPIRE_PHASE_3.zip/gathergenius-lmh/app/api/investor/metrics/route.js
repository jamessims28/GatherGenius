import { NextResponse } from "next/server";
export async function GET(){
 return NextResponse.json({
  ok:true,
  metrics:{
   mrr:12500,
   bookings:32000,
   cities:5,
   vendors:128
  }
 });
}
