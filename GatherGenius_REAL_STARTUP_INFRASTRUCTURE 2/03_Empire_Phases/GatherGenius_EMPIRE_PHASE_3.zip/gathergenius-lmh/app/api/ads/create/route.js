import { NextResponse } from "next/server";
export async function POST(req){
  const body = await req.json();
  return NextResponse.json({
    ok:true,
    message:"Ad campaign created (Phase 2 scaffold).",
    campaign: body
  });
}
