# GatherGenius Mobile App

Expo mobile app for iOS + Android.

## Setup

```bash
npm install
cp .env.example .env
npm run start
```

Set `EXPO_PUBLIC_API_BASE_URL` to your Vercel URL.

## Screens
- Home marketplace
- Live vendor map
- AI event autopilot
- Bookings pipeline
- Profile / plan settings
