import React, { useState } from 'react';
import { View, Text, Pressable, TextInput, ScrollView, StyleSheet } from 'react-native';
const styles = StyleSheet.create({
  page:{flex:1,backgroundColor:'#f9f6f1',padding:20}, card:{backgroundColor:'rgba(255,255,255,.82)',borderColor:'#e7ded2',borderWidth:1,borderRadius:24,padding:18,marginBottom:14},
  title:{fontSize:30,fontWeight:'300',color:'#1f2937',marginBottom:8}, sub:{color:'#78716c',marginBottom:12}, btn:{backgroundColor:'#1f2937',padding:14,borderRadius:18,alignItems:'center',marginTop:10}, btnText:{color:'white',fontWeight:'600'}, input:{backgroundColor:'white',borderColor:'#e7ded2',borderWidth:1,borderRadius:16,padding:12,marginVertical:8}, orb:{width:72,height:72,borderRadius:36,backgroundColor:'white',shadowColor:'#f3e9dc',shadowOpacity:1,shadowRadius:35,marginBottom:20}
});

export default function HomeScreen({ navigation }) {
  return <ScrollView style={styles.page}><View style={styles.orb}/><Text style={styles.title}>GatherGenius</Text><Text style={styles.sub}>AI event marketplace by LMH Enterprise LLC.</Text><View style={styles.card}><Text style={styles.title}>Find everything your event needs.</Text><Text style={styles.sub}>Vendors, venues, food, DJs, lighting, tickets, and event layouts.</Text><Pressable style={styles.btn} onPress={()=>navigation.navigate('Map')}><Text style={styles.btnText}>Find Vendors Near Me</Text></Pressable></View><View style={styles.card}><Text style={styles.title}>Start with AI</Text><Text style={styles.sub}>Describe your event and create a plan instantly.</Text><Pressable style={styles.btn} onPress={()=>navigation.navigate('AI')}><Text style={styles.btnText}>Open AI Planner</Text></Pressable></View></ScrollView>;
}
