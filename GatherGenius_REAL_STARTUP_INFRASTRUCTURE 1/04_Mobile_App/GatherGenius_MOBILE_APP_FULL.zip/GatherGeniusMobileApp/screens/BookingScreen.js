import React, { useState } from 'react';
import { View, Text, Pressable, TextInput, ScrollView, StyleSheet } from 'react-native';
const styles = StyleSheet.create({
  page:{flex:1,backgroundColor:'#f9f6f1',padding:20}, card:{backgroundColor:'rgba(255,255,255,.82)',borderColor:'#e7ded2',borderWidth:1,borderRadius:24,padding:18,marginBottom:14},
  title:{fontSize:30,fontWeight:'300',color:'#1f2937',marginBottom:8}, sub:{color:'#78716c',marginBottom:12}, btn:{backgroundColor:'#1f2937',padding:14,borderRadius:18,alignItems:'center',marginTop:10}, btnText:{color:'white',fontWeight:'600'}, input:{backgroundColor:'white',borderColor:'#e7ded2',borderWidth:1,borderRadius:16,padding:12,marginVertical:8}, orb:{width:72,height:72,borderRadius:36,backgroundColor:'white',shadowColor:'#f3e9dc',shadowOpacity:1,shadowRadius:35,marginBottom:20}
});

export default function BookingScreen(){return <ScrollView style={styles.page}><Text style={styles.title}>Bookings</Text><Text style={styles.sub}>Track vendor booking requests, deposits, and event payments.</Text>{['Requested','Pending Deposit','Confirmed'].map(x=><View key={x} style={styles.card}><Text style={styles.title}>{x}</Text><Text>Vendor booking pipeline status.</Text></View>)}</ScrollView>}
