Add app icon.png here before App Store submission.
