const BASE_URL = process.env.EXPO_PUBLIC_API_BASE_URL || 'https://gathergenius-lmh.vercel.app';

export async function searchVendors({ query='event vendors', lat=38.4221, lng=-77.4083 } = {}) {
  const res = await fetch(`${BASE_URL}/api/vendors/search-nearby`, {
    method: 'POST', headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ query, lat, lng })
  });
  return res.json();
}

export async function createAutopilotPlan(prompt) {
  const res = await fetch(`${BASE_URL}/api/ai/autopilot`, {
    method: 'POST', headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ prompt })
  });
  return res.json();
}

export async function submitVendor(vendor) {
  const res = await fetch(`${BASE_URL}/api/vendors/join`, {
    method: 'POST', headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ vendor })
  });
  return res.json();
}
