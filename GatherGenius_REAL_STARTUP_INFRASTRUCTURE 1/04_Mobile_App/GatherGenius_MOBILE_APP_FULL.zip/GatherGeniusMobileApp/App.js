import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { Ionicons } from '@expo/vector-icons';
import HomeScreen from './screens/HomeScreen';
import MapScreen from './screens/MapScreen';
import AIScreen from './screens/AIScreen';
import BookingScreen from './screens/BookingScreen';
import ProfileScreen from './screens/ProfileScreen';
const Tab = createBottomTabNavigator();
export default function App(){return <NavigationContainer><Tab.Navigator screenOptions={({route})=>({headerStyle:{backgroundColor:'#f9f6f1'},tabBarStyle:{backgroundColor:'#fffaf3'},tabBarIcon:({color,size})=>{const icons={Home:'home-outline',Map:'map-outline',AI:'sparkles-outline',Bookings:'calendar-outline',Profile:'person-outline'};return <Ionicons name={icons[route.name]} size={size} color={color}/>}})}><Tab.Screen name="Home" component={HomeScreen}/><Tab.Screen name="Map" component={MapScreen}/><Tab.Screen name="AI" component={AIScreen}/><Tab.Screen name="Bookings" component={BookingScreen}/><Tab.Screen name="Profile" component={ProfileScreen}/></Tab.Navigator></NavigationContainer>}
