# Zapier Automation Setup

## Zap 1: New lead follow-up
Trigger: New row in Airtable / Google Sheets
Action: Send Gmail draft using Message 1
Action: Create follow-up task due in 3 days

## Zap 2: Follow-up reminder
Trigger: Follow-up date arrives
Action: Send Gmail draft using Follow-up Day 3
Action: Update status to Follow Up

## Zap 3: Vendor says yes
Trigger: Status changes to Interested
Action: Send onboarding link
Action: Create vendor record in Supabase
Action: Notify James

## Fields
- Business Name
- Category
- City
- Contact Name
- Email
- Phone
- Status
- Priority
- Next Follow-up
- Plan Pitch
