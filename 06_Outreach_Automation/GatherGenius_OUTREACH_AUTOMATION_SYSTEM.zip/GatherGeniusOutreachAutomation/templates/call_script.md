# Vendor Call Script

Hey, I run GatherGenius, a platform that connects event planners with vendors like you.

We’re onboarding businesses locally right now. I can list you free, and if you want more exposure, we offer featured placement.

Would you like me to get your business set up?

## Objection: I’m not interested
No problem. I can still add a free basic listing so people can find you. You only upgrade if it brings value.

## Objection: How much?
Basic is free. Featured placement is $49/month. Elite placement is $149/month.
