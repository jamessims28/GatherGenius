# Vendor Outreach Email Sequence

## Message 1
Subject: Event bookings in {{city}}

Hey {{contact_name}}, quick question.

Do you currently get consistent event bookings?

I built GatherGenius, a platform that sends vendors real event requests in {{city}}. I can list {{business_name}} free, and featured vendors get priority leads.

Want me to add your business?

— James / LMH Enterprise LLC

## Follow-up Day 3
Subject: Free vendor listing

Just checking back. I can add {{business_name}} to GatherGenius free this week. If it brings leads, featured placement is available later.

## Follow-up Day 7
Subject: Closing first vendor group

I’m closing the first local vendor group. Do you want a free listing before I lock the launch batch?
