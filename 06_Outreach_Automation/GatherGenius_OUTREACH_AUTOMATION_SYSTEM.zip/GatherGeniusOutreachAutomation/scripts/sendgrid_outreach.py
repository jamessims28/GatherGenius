import csv, os, requests

SENDGRID_API_KEY = os.getenv('SENDGRID_API_KEY')
FROM_EMAIL = os.getenv('FROM_EMAIL')
INPUT = 'followup_queue.csv'

def personalize(template, row):
    for key, value in row.items():
        template = template.replace('{{' + key + '}}', value or '')
    return template

def send_email(to, subject, body):
    if not SENDGRID_API_KEY or not FROM_EMAIL:
        raise RuntimeError('Set SENDGRID_API_KEY and FROM_EMAIL first')
    payload = {'personalizations':[{'to':[{'email':to}]}],'from':{'email':FROM_EMAIL},'subject':subject,'content':[{'type':'text/plain','value':body}]}
    r = requests.post('https://api.sendgrid.com/v3/mail/send', headers={'Authorization':f'Bearer {SENDGRID_API_KEY}','Content-Type':'application/json'}, json=payload, timeout=20)
    print(to, r.status_code)

def main():
    with open(INPUT, newline='', encoding='utf-8') as f:
        rows=list(csv.DictReader(f))
    for row in rows:
        if not row.get('email'):
            continue
        subject = f"Event bookings in {row.get('city','your area')}"
        body = f"Hey {row.get('contact_name') or 'there'}, quick question. Do you currently get consistent event bookings? I built GatherGenius to send vendors real event requests in {row.get('city','your area')}. I can list {row.get('business_name','your business')} free, and featured vendors get priority leads. Want me to add your business?"
        send_email(row['email'], subject, body)

if __name__ == '__main__':
    main()
