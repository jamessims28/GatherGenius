import csv
from datetime import datetime, timedelta

INPUT = 'vendor_leads_template.csv'
OUTPUT = 'followup_queue.csv'

def main():
    today = datetime.now().date()
    with open(INPUT, newline='', encoding='utf-8') as f:
        leads = list(csv.DictReader(f))
    rows = []
    for lead in leads:
        rows.append({**lead, 'message_step': 'Message 1', 'send_date': today.isoformat()})
        rows.append({**lead, 'message_step': 'Follow-up Day 3', 'send_date': (today + timedelta(days=3)).isoformat()})
        rows.append({**lead, 'message_step': 'Follow-up Day 7', 'send_date': (today + timedelta(days=7)).isoformat()})
    with open(OUTPUT, 'w', newline='', encoding='utf-8') as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        writer.writeheader(); writer.writerows(rows)
    print(f'Created {OUTPUT} with {len(rows)} scheduled messages')

if __name__ == '__main__':
    main()
