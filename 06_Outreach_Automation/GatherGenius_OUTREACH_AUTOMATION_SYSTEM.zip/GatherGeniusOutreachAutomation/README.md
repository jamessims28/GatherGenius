# GatherGenius Vendor Outreach Automation System

This package gives you a full first-10-vendors execution system.

## Includes
- Vendor outreach tracker Excel workbook
- SendGrid outreach sender script
- Follow-up queue generator
- Airtable/Zapier setup guide
- DM, email, and phone scripts
- Lead template CSV

## Recommended workflow
1. Add leads to `vendor_leads_template.csv` or the Excel tracker.
2. Upload leads to Airtable or keep the workbook as your CRM.
3. Use `scripts/generate_followups.py` to create next follow-up dates.
4. Use `scripts/sendgrid_outreach.py` only after you add your verified SendGrid key and sender.
