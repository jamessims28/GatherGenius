 "use client";
import React,{useState} from "react";
import {Megaphone,Brain,Globe,MapPin} from "lucide-react";

export default function Page(){
 const [tab,setTab]=useState("phase2");

 return (
  <main className="p-6">
   <h1 className="text-3xl mb-4">Empire Phase 2</h1>

   <div className="flex gap-3 mb-6">
    <button onClick={()=>setTab("ads")}>Ads</button>
    <button onClick={()=>setTab("ai")}>AI Matching</button>
    <button onClick={()=>setTab("cities")}>City Expansion</button>
   </div>

   {tab==="ads" && (
    <div>
     <h2 className="text-xl mb-2 flex gap-2"><Megaphone/> Ad Engine</h2>
     <p>Create paid vendor promotions.</p>
    </div>
   )}

   {tab==="ai" && (
    <div>
     <h2 className="text-xl mb-2 flex gap-2"><Brain/> AI Matching</h2>
     <p>Auto-match vendors to events.</p>
    </div>
   )}

   {tab==="cities" && (
    <div>
     <h2 className="text-xl mb-2 flex gap-2"><Globe/> City Expansion</h2>
     <p>Launch new marketplace cities.</p>
    </div>
   )}
  </main>
 )
}
